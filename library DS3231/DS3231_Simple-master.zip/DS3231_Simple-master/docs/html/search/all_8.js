var searchData=
[
  ['setalarm',['setAlarm',['../class_d_s3231___simple.html#a2b544372ac591992debe0c37375817a7',1,'DS3231_Simple::setAlarm(const DateTime &amp;AlarmTime, uint8_t AlarmMode)'],['../class_d_s3231___simple.html#afd01f1d029f7155e59df4e01265c688e',1,'DS3231_Simple::setAlarm(uint8_t AlarmMode)']]]
];
