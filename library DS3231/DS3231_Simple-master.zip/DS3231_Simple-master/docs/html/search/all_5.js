var searchData=
[
  ['makeeepromspace',['makeEEPROMSpace',['../class_d_s3231___simple.html#a4a5ae783b377ffa4cdb7c02e969a5e11',1,'DS3231_Simple']]]
];
